#!/bin/sh
if [ -d "/tmp/adbyby" ]; then
	iptables -t nat -D PREROUTING -p tcp --dport 80 -j REDIRECT --to-ports 8118 >/dev/null 2>&1
	killall -9 adbyby >/dev/null 2>&1
	rm -fr /tmp/adbyby
fi
if [ -f "/etc/storage/adbyby/adbyby.tar.bz2" ]; then
	mkdir -p /tmp/adbyby
	tar jxf /etc/storage/adbyby/adbyby.tar.bz2 -C /tmp/adbyby
	chmod -R 777 /tmp/adbyby
	if [ -f "/tmp/adbyby/adhook.ini" ]; then
		export lan_ip=$(nvram get lan_ipaddr);
		sed -i "s/lan_ip/$lan_ip/g" /tmp/adbyby/adhook.ini
		/bin/sh /tmp/adbyby/startadbb
	fi
else
	rm -fr /etc/storage/adbyby
fi
